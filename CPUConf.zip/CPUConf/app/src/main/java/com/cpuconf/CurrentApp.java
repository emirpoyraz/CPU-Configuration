package com.cpuconf;

/**
 * Created by emir on 3/29/16.
 */
public class CurrentApp {
}
